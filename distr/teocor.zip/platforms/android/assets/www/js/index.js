/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
        
        // ----------------------------------------------------------------- //
        
        /**
         * On client connected callback function example
         * 
         * @param {type} ev
         * @returns {undefined}
         */
        function open_func(ev) {

            // Client name (random created)
            teocli.client_name = "ws-" + Math.floor((Math.random() * 100) + 1);

            console.log('onopen', teocli.client_name, ev); 

            teocli.login(teocli.client_name); // Send login command to L0 server
            teocli.peers("ps-server"); // Send peers list request command to "ps-server" peer
            teocli.echo("ps-server", "Hello " + teocli.client_name + "!"); // Send echo command to "ps-server" peer
        }        
                
        /**
         * On message callback function example
         * 
         * @param {type} ev
         * @returns {undefined}
         */
        function message_func(ev) {

          console.log('onmessage', ev, ev.data.slice(0,20));

          // Process command. If command not processed show it in html page
          if(!teocli.process(ev.data)) {

              var div = document.createElement('div');
              div.innerHTML = ev.data;
              document.getElementById('app').appendChild(div);
          }
        }        
        
        // Connect to websocket server
        //var ws = new WebSocket('ws://' + location.host + '/ws');
        var ws = new WebSocket('ws://' + '10.12.35.53:8080' + '/ws');
  
        // Create Teocli object
        var teocli = Teocli(ws);
        teocli.init();
        
        //teocli.
        
        // Define received data callbacks
//        teocli.onecho = echo_func; // Calls when echo_answer received
//        teocli.onpeers = peers_func; // Calls when peers_answer received
//        teocli.onother = other_func; // Calls when some other command received
        // Define common websocket callbacks
        teocli.onopen = open_func; // Calls when client connected to websocket
//        teocli.onclose = close_func; // Calls when client connected to websocket
        teocli.onmessage = message_func; // Calls when websocket message received
//        teocli.onerror = error_func; // Calls when websocket error hapend        
    }
};

app.initialize();